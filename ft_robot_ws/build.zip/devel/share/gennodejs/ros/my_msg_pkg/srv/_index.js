
"use strict";

let master = require('./master.js')
let sensor = require('./sensor.js')
let remot = require('./remot.js')

module.exports = {
  master: master,
  sensor: sensor,
  remot: remot,
};
