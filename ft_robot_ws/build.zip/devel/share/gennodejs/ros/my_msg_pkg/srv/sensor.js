// Auto-generated. Do not edit!

// (in-package my_msg_pkg.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class sensorRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.request = null;
    }
    else {
      if (initObj.hasOwnProperty('request')) {
        this.request = initObj.request
      }
      else {
        this.request = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type sensorRequest
    // Serialize message field [request]
    bufferOffset = _serializer.int32(obj.request, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type sensorRequest
    let len;
    let data = new sensorRequest(null);
    // Deserialize message field [request]
    data.request = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'my_msg_pkg/sensorRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '650f0ccd41c8f8d53ada80be6ddde434';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # 客户端请求时发送的两个数字
    int32 request
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new sensorRequest(null);
    if (msg.request !== undefined) {
      resolved.request = msg.request;
    }
    else {
      resolved.request = 0
    }

    return resolved;
    }
};

class sensorResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.temperature = null;
      this.humidity = null;
      this.smoke = null;
      this.noise = null;
    }
    else {
      if (initObj.hasOwnProperty('temperature')) {
        this.temperature = initObj.temperature
      }
      else {
        this.temperature = 0.0;
      }
      if (initObj.hasOwnProperty('humidity')) {
        this.humidity = initObj.humidity
      }
      else {
        this.humidity = 0;
      }
      if (initObj.hasOwnProperty('smoke')) {
        this.smoke = initObj.smoke
      }
      else {
        this.smoke = 0.0;
      }
      if (initObj.hasOwnProperty('noise')) {
        this.noise = initObj.noise
      }
      else {
        this.noise = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type sensorResponse
    // Serialize message field [temperature]
    bufferOffset = _serializer.float32(obj.temperature, buffer, bufferOffset);
    // Serialize message field [humidity]
    bufferOffset = _serializer.int32(obj.humidity, buffer, bufferOffset);
    // Serialize message field [smoke]
    bufferOffset = _serializer.float32(obj.smoke, buffer, bufferOffset);
    // Serialize message field [noise]
    bufferOffset = _serializer.int32(obj.noise, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type sensorResponse
    let len;
    let data = new sensorResponse(null);
    // Deserialize message field [temperature]
    data.temperature = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [humidity]
    data.humidity = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [smoke]
    data.smoke = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [noise]
    data.noise = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 16;
  }

  static datatype() {
    // Returns string type for a service object
    return 'my_msg_pkg/sensorResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7d978294569a957ff7a75f8e06d1b6f8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # 服务器响应发送的数据
    # 定义一个包含温度、湿度、烟雾和噪声的传感器数据消息类型
    float32 temperature    # 温度，使用float32类型
    int32 humidity         # 湿度，使用int32类型
    float32 smoke          # 烟雾浓度，使用float32类型
    int32 noise            # 噪声水平，使用int32类型
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new sensorResponse(null);
    if (msg.temperature !== undefined) {
      resolved.temperature = msg.temperature;
    }
    else {
      resolved.temperature = 0.0
    }

    if (msg.humidity !== undefined) {
      resolved.humidity = msg.humidity;
    }
    else {
      resolved.humidity = 0
    }

    if (msg.smoke !== undefined) {
      resolved.smoke = msg.smoke;
    }
    else {
      resolved.smoke = 0.0
    }

    if (msg.noise !== undefined) {
      resolved.noise = msg.noise;
    }
    else {
      resolved.noise = 0
    }

    return resolved;
    }
};

module.exports = {
  Request: sensorRequest,
  Response: sensorResponse,
  md5sum() { return '89ccd778bf7336e0997505206f7251e3'; },
  datatype() { return 'my_msg_pkg/sensor'; }
};
