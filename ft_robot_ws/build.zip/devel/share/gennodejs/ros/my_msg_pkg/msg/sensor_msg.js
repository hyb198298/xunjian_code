// Auto-generated. Do not edit!

// (in-package my_msg_pkg.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class sensor_msg {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.temperature = null;
      this.humidity = null;
      this.smoke = null;
      this.noise = null;
    }
    else {
      if (initObj.hasOwnProperty('temperature')) {
        this.temperature = initObj.temperature
      }
      else {
        this.temperature = 0.0;
      }
      if (initObj.hasOwnProperty('humidity')) {
        this.humidity = initObj.humidity
      }
      else {
        this.humidity = 0;
      }
      if (initObj.hasOwnProperty('smoke')) {
        this.smoke = initObj.smoke
      }
      else {
        this.smoke = 0.0;
      }
      if (initObj.hasOwnProperty('noise')) {
        this.noise = initObj.noise
      }
      else {
        this.noise = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type sensor_msg
    // Serialize message field [temperature]
    bufferOffset = _serializer.float32(obj.temperature, buffer, bufferOffset);
    // Serialize message field [humidity]
    bufferOffset = _serializer.int32(obj.humidity, buffer, bufferOffset);
    // Serialize message field [smoke]
    bufferOffset = _serializer.float32(obj.smoke, buffer, bufferOffset);
    // Serialize message field [noise]
    bufferOffset = _serializer.int32(obj.noise, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type sensor_msg
    let len;
    let data = new sensor_msg(null);
    // Deserialize message field [temperature]
    data.temperature = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [humidity]
    data.humidity = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [smoke]
    data.smoke = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [noise]
    data.noise = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'my_msg_pkg/sensor_msg';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7d978294569a957ff7a75f8e06d1b6f8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 temperature    # 温度，使用float32类型
    int32 humidity              # 湿度，使用int32类型
    float32 smoke              # 烟雾浓度，使用float32类型
    int32 noise                     # 噪声水平，使用int32类型
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new sensor_msg(null);
    if (msg.temperature !== undefined) {
      resolved.temperature = msg.temperature;
    }
    else {
      resolved.temperature = 0.0
    }

    if (msg.humidity !== undefined) {
      resolved.humidity = msg.humidity;
    }
    else {
      resolved.humidity = 0
    }

    if (msg.smoke !== undefined) {
      resolved.smoke = msg.smoke;
    }
    else {
      resolved.smoke = 0.0
    }

    if (msg.noise !== undefined) {
      resolved.noise = msg.noise;
    }
    else {
      resolved.noise = 0
    }

    return resolved;
    }
};

module.exports = sensor_msg;
