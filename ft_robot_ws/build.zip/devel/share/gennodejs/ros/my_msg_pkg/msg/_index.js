
"use strict";

let remot_msg = require('./remot_msg.js');
let sensor_msg = require('./sensor_msg.js');

module.exports = {
  remot_msg: remot_msg,
  sensor_msg: sensor_msg,
};
